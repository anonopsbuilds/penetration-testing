This is a program that will install Metasploit-Framework and Armitage on to Ubuntu, though I assume it will work on any Debian-based Linux Distro.
This was made using a combination of my own code, darkoperator's, a nightly Metasploit installer from rapid7, and an update pull request from itsdarklikehell. 
Please enjoy this program.

In order to run this program navigate to the folder it is in and type the following into a terminal:

chmod +x ArmitageInstaller && sudo bash ArmitageInstaller



After the script has completed, you can start a Metasploit console by typing sudo msfconsole. 
To start Armitage type sudo -E armitage.

Thank you so much for using my code!

I disclaim ALL responsibility for what you do with the programs that this code will install as well as the code itself.
